import { getLocale, getTranslations } from "next-intl/server";
import { api } from "@/lib/api";
import "./_Download.scss";
import Reveal from "@/components/animations/Reveal";

const Download = async () => {
    const locale = await getLocale();
    const t = await getTranslations("download");

    const response = await api.getPage("download", locale);
    const data = response.data;

    const apps = [
        {
            name: t("apple"),
            icon: "/images/icons/apple.svg",
            href: "#",
        },
        {
            name: t("google"),
            icon: "/images/icons/google.svg",
            href: "#",
        },
        {
            name: t("windows"),
            icon: "/images/icons/windows.svg",
            href: "#",
        },
        {
            name: t("mac"),
            icon: "/images/icons/mac.svg",
            href: "#",
        },
    ];

    return (
        <section className="download pb-80">
            <div className="container">

                <Reveal
                    animation="fade-up-blur"
                >
                    <div className="download-box radius-40 p-40 d-flex align-items-center justify-content-between">

                        <div className="info">

                            <Reveal
                                animation="fade-left"
                            >
                                <h3 className="fsz-35 fw-800 mb-2">
                                    {data.first_title}
                                </h3>
                            </Reveal>

                            <Reveal
                                animation="fade-left-blur"
                                delay={0.15}
                            >
                                <div className="text fsz-20 fw-500 mt-10">
                                    {data.second_title}
                                </div>
                            </Reveal>

                        </div>

                        <div className="apps row g-3">

                            {apps.map((app, index) => (
                                <div
                                    className="col-6 col-sm-3"
                                    key={app.name}
                                >
                                    <Reveal
                                        animation={
                                            index === 0
                                                ? "fade-up"
                                                : index === 1
                                                ? "fade-down"
                                                : index === 2
                                                ? "zoom-in"
                                                : "fade-up-blur"
                                        }
                                        delay={0.15 + index * 0.1}
                                    >
                                        <a
                                            href={app.href}
                                            className="app-item radius-15 overflow-hidden text-center"
                                        >
                                            <div className="ico df-center">
                                                <img
                                                    src={app.icon}
                                                    alt={app.name}
                                                    className="icon-45"
                                                />
                                            </div>

                                            <span className="label bg_primary d-block fsz-14 fw-500">
                                                {app.name}
                                            </span>
                                        </a>
                                    </Reveal>
                                </div>
                            ))}

                        </div>

                    </div>
                </Reveal>

            </div>
        </section>
    );
};

export default Download;